/**
 * Copyright (c) 2014, 2015 EclipseSource.
 * All rights reserved.
 */

require("./TabrisExtensions.js");
var helper = require("./Helper.js");
var tabrisConnect = require("./TabrisConnect.js");
var profilePage = require("./pages/ProfilePage.js");
var helpPage = require("./pages/HelpPage.js");
var invitePage = require("./pages/InvitePage.js");
var scriptsTab = require("./tabs/ScriptsTab.js");
var userAppTab = require("./tabs/UserAppTab.js");
var examplesTab = require("./tabs/ExamplesTab.js");
var urlTab = require("./tabs/UrlTab.js");

var TABFOLDER_FOREGROUND = helper.isAndroid() ? "white" : "#009688";
var TABFOLDER_BACKGROUND = helper.isAndroid() ? "#009688" : "white";
var LAST_OPEN_TAB_KEY = "settings:lastOpenTab";
var SHOW_HELP_ON_STARTUP_KEY = "settings:showHelpOnStartup";

var signOutWebView = null;

tabrisConnect.addAuthenticationListener(function(event) {
  if (event.type === "signIn") {
    handleSignIn(event.token, event.error, event.errorCode);
  } else {
    handleSignOut();
  }
});

// Main UI

if (helper.isAndroid()) {
  tabris.ui.set({background: "#009688", foreground: "white"});
}

var profileAction = tabris.create("Action", {
  title: "",
  image: {src: helper.ICONS_PREFIX + "action_profile@2x.png", scale: 2},
  placementPriority: "high"
}).on("selection", function() {
  profilePage.create().open();
});

var mainPage = tabris.create("Page", {
  title: "Tabris.js",
  topLevel: true
}).on("appear", function() {
  profileAction.set("visible", true);
}).on("disappear", function() {
  profileAction.set("visible", false);
});

var folder = tabris.create("TabFolder", {
  tabBarLocation: "top",
  layoutData: {left: 0, top: 0, right: 0, bottom: 0},
  foreground: TABFOLDER_FOREGROUND,
  background: TABFOLDER_BACKGROUND,
  paging: helper.isAndroid()
}).on("change:selection", function() {
  var selectedTab = folder.get("selection");
  localStorage.setItem(LAST_OPEN_TAB_KEY, selectedTab._storeId);
}).appendTo(mainPage);

scriptsTab.create().appendTo(folder);
scriptsTab.loadScripts();
if (userAppTab.hasUserApp()) {
  userAppTab.create().appendTo(folder);
} else {
  examplesTab.create().appendTo(folder);
  examplesTab.loadExamples();
}
if (tabrisConnect.isUserAuthenticated()) {
  urlTab.create().appendTo(folder);
}
folder.set("selection", getLastOpenTab());

mainPage.open();

if (localStorage.getItem(SHOW_HELP_ON_STARTUP_KEY) !== "false") {
  localStorage.setItem(SHOW_HELP_ON_STARTUP_KEY, "false");
  helpPage.create(true).open();
}

// Helper

function handleSignIn(token, error, errorCode) {
  if (token) {
    urlTab.create().appendTo(folder);
  } else if (error) {
    switch (errorCode) {
      case "601":
        githubSignOut();
        invitePage.create().open();
        break;
      default:
        helper.showDialog("Connection Error", decodeURIComponent(error));
    }
  } else {
    helper.showDialog("Unexpected Server Response", "Please try again later");
  }
}

function handleSignOut() {
  githubSignOut();
  if (urlTab.getTab() === folder.get("selection")) {
    folder.set("selection", scriptsTab.getTab());
  }
  urlTab.destroy();
}

function githubSignOut() {
  if (helper.isNetworkConnected()) {
    if (signOutWebView != null) {
      signOutWebView.dispose();
    }
    var submitLogoutFormScript = "(function(){" +
      "var forms=document.getElementsByTagName('form');" +
      "for(var i=0;i<forms.length;i++){" +
      "if(forms[i].method==='post' && forms[i].action.indexOf('/logout')!==-1){" +
      "forms[i].submit();break;}}}());";
    signOutWebView = tabris.create("WebView", {
      visible: false,
      layoutData: {left: 0, right: 0, top: 0, bottom: 0},
      url: "https://github.com/logout"
    }).on("load", function() {
      if (submitLogoutFormScript) {
        this._nativeCall("evaluate", {script: submitLogoutFormScript});
        submitLogoutFormScript = null;
      }
    }).appendTo(mainPage);
  }
}

function getLastOpenTab() {
  var lastOpenTabId = localStorage.getItem(LAST_OPEN_TAB_KEY);
  if (lastOpenTabId && lastOpenTabId === userAppTab.getTabId()) {
    return userAppTab.getTab();
  } else if (lastOpenTabId && lastOpenTabId === examplesTab.getTabId()) {
    return examplesTab.getTab();
  } else if (lastOpenTabId && lastOpenTabId === urlTab.getTabId()) {
    return urlTab.getTab();
  }
  return scriptsTab.getTab();
}
